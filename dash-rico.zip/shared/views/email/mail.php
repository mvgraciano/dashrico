<?php $v->layout("_theme", ["title" => $subject]); ?>

<?= $message; ?>